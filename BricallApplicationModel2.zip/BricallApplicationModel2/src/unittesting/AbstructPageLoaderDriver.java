package unittesting;

import com.hp.lft.report.ReportException;
import com.hp.lft.report.Reporter;
import com.hp.lft.report.Status;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;
import com.hp.lft.sdk.web.Browser;
import com.hp.lft.sdk.web.BrowserDescription;
import com.hp.lft.sdk.web.BrowserFactory;
import com.hp.lft.sdk.web.BrowserType;
import java.net.URI;


public class AbstructPageLoaderDriver {

    protected  static Browser browser;
    public AbstructPageLoaderDriver(Browser browser){
    	AbstructPageLoaderDriver.browser=browser;
    }

    public void setBrowser() throws Exception {
        ModifiableSDKConfiguration config = new ModifiableSDKConfiguration();
        config.setServerAddress(new URI("ws://localhost:5095"));
        SDK.init(config);

        browser= BrowserFactory.launch(BrowserType.INTERNET_EXPLORER);
//        browser= BrowserFactory.attach(new BrowserDescription.Builder()
//	    		 .type(BrowserType.INTERNET_EXPLORER).build());
         
//        Thread.sleep(15000);
       

    }
    
 
    
    public void attachBrowser() throws Exception {
    	System.out.println("Start Attachbrowser ");	
        browser= BrowserFactory.attach(new BrowserDescription.Builder().type(BrowserType.INTERNET_EXPLORER).build());
        System.out.println("End Attachbrowser ");
////    	Thread.sleep(15000);
////      browser= BrowserFactory.attach(new BrowserDescription.Builder().title("BR!CALL").build());
//       String title = browser.getOpenTitle();
//       String URL = browser.getOpenURL();
//       System.out.println(title);
//       System.out.println(URL);
    		  
    }
    
    public void setSecurityWindows1(String uid,String pass) throws GeneralLeanFtException, ReportException {
    
    	ApplicationModel appModel = new ApplicationModel(browser);
		if (appModel.SCuritDeWindowsDialog().exists(20)) {
			appModel.SCuritDeWindowsDialog().highlight();
			System.out.println("La fen�tre de s�curit� Windows_Echonet s'affiche");
			Reporter.reportEvent("S�curit� Windows", "La fen�tre de s�curit� Windows_Echonet s'affiche", Status.Warning);
			appModel.SCuritDeWindowsDialog().WinEditEditField().setText(uid);
			appModel.SCuritDeWindowsDialog().WinEditEditField1().setText(pass);
			appModel.SCuritDeWindowsDialog().OKButton().click();
			
		}
		else {
			System.out.println("La fen�tre de s�curit� Windows_Echonet n'est pas s'affich�");

		}

    } 
    
    public void setSecurityWindows2(String user,String pwd) throws GeneralLeanFtException {
    	
    	ApplicationModel appModel = new ApplicationModel(browser);
		if (appModel.SCuritDeWindowsDialog().exists(20)) {
			appModel.SCuritDeWindowsDialog().highlight();
			System.out.println("La fen�tre de s�curit� Windows_Bricall s'affiche");
			appModel.SCuritDeWindowsDialog().WinEditEditField().setText(user);
			appModel.SCuritDeWindowsDialog().WinEditEditField1().setText(pwd);
			appModel.SCuritDeWindowsDialog().OKButton().click();
		}

    } 
    
    public LoginPage PageNavigateToWebApp(String url) throws GeneralLeanFtException {
        browser.navigate(url);
        return new LoginPage(browser);
    }

    public void syncBrowser() throws GeneralLeanFtException {
        browser.sync();
    }

    public void closeDriver(){
        System.out.println("This step will close and cleanup the browser");
        try {
            browser.close();
        } catch (GeneralLeanFtException e) {
            System.out.println("browser is already closed");
        }
    }

}
