package unittesting;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;
import com.hp.lft.report.*;


public class LoginPage extends AbstructPageLoaderDriver  {

    //user
    EditFieldDescription txt_userName =  new EditFieldDescription.Builder().type("text").tagName("INPUT").name("user").build();
    
    //password
    EditFieldDescription txt_password =  new EditFieldDescription.Builder().type("password").tagName("INPUT").name("password").build();
    
    //Se connecter 
    ButtonDescription button_SihnIn = new ButtonDescription.Builder().buttonType("submit").tagName("BUTTON").name(" Se connecter ").build();
    
    public LoginPage(Browser browser){
        super(browser);
    }

    public LoginPage setUsername(String userName)  throws GeneralLeanFtException, ReportException{
    	  EditField usernameField = browser.describe(EditField.class, txt_userName);
    	  System.out.println("check start for userName ");
    	  if (usernameField.exists(15)) {
   		       System.out.println("L'objet userName existe");
               Reporter.reportEvent("LoginPage", "L'objet usernameField existe" , Status.Passed);
    		   usernameField.setValue(userName);
    	  }
    	  else {
  		        System.out.println("L'objet username n'existe pas");
    		    Reporter.reportEvent("LoginPage", "L'objet usernameField n'existe pas" , Status.Failed);
    		    }
    	  
	      return  new LoginPage(browser);
    }

    public LoginPage setPassword(String password) throws GeneralLeanFtException, ReportException {
    	  EditField passWordField = browser.describe(EditField.class, txt_password);
    	  if (passWordField.exists(15)) {
    		  System.out.println("L'objet passWord existe");
    		  Reporter.reportEvent("LoginPage", "L'objet passWordField existe" , Status.Passed);
    		  passWordField.setValue(password);
    	  }
    	  else {
    		  System.out.println("L'objet passWord n'existe pas");
    		  Reporter.reportEvent("LoginPage", "L'objet passWordField n'existe pas" , Status.Failed);
    		  
    	  }
	      return new LoginPage(browser);
    }

    public LoginPage clickLoginBtn() throws GeneralLeanFtException, ReportException {
    	  Button signIn = browser.describe(Button.class, button_SihnIn);
    	  if(signIn.exists(15)) {
    		 System.out.println("L'objet boutton 'se connecter' existe"); 
    		 Reporter.reportEvent("LoginPage", "L'objet bouton 'se connecter' existe" , Status.Passed); 
    		 signIn.click();
    		 
    	  }
    	  else {
    		 System.out.println("L'objet boutton 'se connecter' n'existe pas");  
    		 Reporter.reportEvent("LoginPage", "L'objet bouton 'se connecter' n'existe pas" , Status.Failed);
    	  }
          
          return new LoginPage(browser);
    }

}
