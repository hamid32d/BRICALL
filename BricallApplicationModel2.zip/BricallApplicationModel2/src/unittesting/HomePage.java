package unittesting;



import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import com.hp.lft.report.ReportException;
import com.hp.lft.report.Reporter;
import com.hp.lft.report.Status;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;

public class HomePage extends AbstructPageLoaderDriver {

//Lien : Artisans    		
    LinkDescription artisan_link = new LinkDescription.Builder()
    		.tagName("A")
    		.innerText("Artisans").build();

//Lien : Logout    
    WebElementDescription logout_elemD = new WebElementDescription.Builder()
    		.tagName("A")
    		.innerText(" Logout ").build();


// Bouton : 'Ajouter Artisan'
    ButtonDescription AjouterArtisan = new ButtonDescription.Builder()
    		.buttonType("submit")
    		.tagName("BUTTON")
    		.name(" Ajouter Artisan ").build(); 
    
//Champ : Nom 
    EditFieldDescription Nom = new EditFieldDescription.Builder().type("text").placeholder("").accessibilityName("")
    		.tagName("INPUT")
    		.name("WebEdit")
    		.index(0).build();

	
	
//Champ : Prenom 
    EditFieldDescription Prenom = new EditFieldDescription.Builder().type("text")
    		.tagName("INPUT")
    		.name("WebEdit")
    		.index(1).build();

//Champ : Date de naissance
    EditFieldDescription DateNaissance =  new EditFieldDescription.Builder().type("text").placeholder("").accessibilityName("")
    		.tagName("INPUT")
    		.name("WebEdit")
    		.index(2).build();
    
//Champ : Ann�es d'exp�rience    
    NumericFieldDescription AnneesExperience = new NumericFieldDescription.Builder()
    		.type("number")
    		.tagName("INPUT")
    		.name("WebNumber").build();
    
//Champ : Ville
    ListBoxDescription Ville = new ListBoxDescription.Builder().role("").accessibilityName("")
    		.tagName("SELECT")
    		.name("select")
    		.index(0).build();
    
//Champ : Quartier
    ListBoxDescription Quartier = new ListBoxDescription.Builder()
	.tagName("SELECT")
	.name("street").build();    
    
  //Champ : M�tier de Base    
    ListBoxDescription MetierdeBase = new ListBoxDescription.Builder()
    		.tagName("SELECT")
    		.name("service").build();
    
//Champ : Telephone
    EditFieldDescription Telephone = new EditFieldDescription.Builder()
    		.type("tel")
    		.placeholder("")
    		.accessibilityName("")
    		.tagName("INPUT")
    		.name("WebEdit")
    		.index(1).build();

//Champ : Statut juridique
    ListBoxDescription StatutJuridique = new ListBoxDescription.Builder()
    		.role("")
    		.accessibilityName("")
    		.tagName("SELECT")
    		.name("select")
    		.index(1).build();
    

//Champ : Description sur l'artisan    
    EditFieldDescription DescriptionArtisan = new EditFieldDescription.Builder()
    		.type("textarea")
    		.tagName("TEXTAREA")
    		.name("description").build();
    
    
 
//Bouton : Valider    
    ButtonDescription button_Valider = new ButtonDescription.Builder()
    		.buttonType("submit")
    		.tagName("BUTTON")
    		.name(" Valider ").build();
    
//Message : Artisan ajout� avec succ�s !    
    WebElementDescription artisan_is_Added = new WebElementDescription.Builder()
    		.className("toast-message ng-star-inserted")
    		.tagName("DIV")
    		.innerText("Artisan ajout� avec succ�s ! ")
    		.visible(true).build();
    
 //
    
    WebElementDescription nom = new WebElementDescription.Builder().tagName("DIV").innerText("Nom").build();

    
public void KeyEvent_method () {
    try {
        Robot robot = new Robot();

        robot.keyPress(KeyEvent.VK_SPACE);
        robot.keyRelease(KeyEvent.VK_SPACE);
        
        robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        
           
    } catch (AWTException e) {
        e.printStackTrace();
    }
}
    
    public HomePage(Browser browser){
        super(browser);
    }
    
    


    
    
    public Boolean isLoggedIn() throws GeneralLeanFtException {  
        Link artisan_link_menu = browser.describe(Link.class, artisan_link);
//        artisan_link_menu.highlight();
        if (artisan_link_menu.exists(10)) return true;
        else return false;
    }

    public HomePage clickLogoutbtn() throws GeneralLeanFtException {
	  WebElement logout_elem = browser.describe(WebElement.class, logout_elemD);
      logout_elem.highlight();
      logout_elem.click();      		
      return new HomePage(browser);

    }
    
    public HomePage clickAjouterArtisanbtn() throws GeneralLeanFtException {
    	Button AjouterArtisanbtn =  browser.describe(Button.class, AjouterArtisan);
    	AjouterArtisanbtn.highlight();
    	AjouterArtisanbtn.click();
        return new HomePage(browser);

    }

   
    public HomePage setNom(String arg1) throws GeneralLeanFtException {
    	EditField NomField =  browser.describe(EditField.class, Nom);
    	NomField.highlight();
    	NomField.setValue(arg1);
    	NomField.click();
    	KeyEvent_method();
        return new HomePage(browser);
    }
       
 
    public HomePage setPrenom(String arg1) throws GeneralLeanFtException {
    	EditField PrenomField =  browser.describe(EditField.class, Prenom);
    	PrenomField.highlight();
    	PrenomField.setValue(arg1);
    	PrenomField.click();
    	KeyEvent_method();
        return new HomePage(browser);

    }
    

    public HomePage setDateNaissance(String arg1) throws GeneralLeanFtException {
    	EditField DateNaissanceField =  browser.describe(EditField.class, DateNaissance);
    	DateNaissanceField.highlight();
    	DateNaissanceField.setValue(arg1);
    	DateNaissanceField.click();
    	KeyEvent_method();
        return new HomePage(browser);

    }
    
    public HomePage SetAnneesExperience(String arg1) throws GeneralLeanFtException {
    	NumericField AnneesExperienceField =  browser.describe(NumericField.class, AnneesExperience);
    	AnneesExperienceField.highlight();
    	AnneesExperienceField.setValue(arg1);
        return new HomePage(browser);

    } 
     
    public HomePage SelectVille(String arg1) throws GeneralLeanFtException {
    	ListBox VilleField =  browser.describe(ListBox.class, Ville);
    	VilleField.highlight();
    	VilleField.select(arg1);
        return new HomePage(browser);

    } 
    
    public HomePage SelectQuartier(String arg1) throws GeneralLeanFtException {
    	ListBox QuartierField =  browser.describe(ListBox.class, Quartier);
    	QuartierField.highlight();
    	QuartierField.select(arg1);
        return new HomePage(browser);

    }
    
    public HomePage SelectQuartiersSecondaires(String arg1) throws GeneralLeanFtException {
        WebElementDescription QuartiersSecondaires = new WebElementDescription.Builder()
        		.tagName("LABEL")
        		.innerText(arg1).build();
        
    	WebElement QuartiersSecondairesField =  browser.describe(WebElement.class, QuartiersSecondaires);
    	QuartiersSecondairesField.highlight();
    	QuartiersSecondairesField.click();
        return new HomePage(browser);

    }
    
    public HomePage SelectMetierdeBase(String arg1) throws GeneralLeanFtException {
    	ListBox MetierdeBaseField =  browser.describe(ListBox.class, MetierdeBase);
    	MetierdeBaseField.highlight();
    	MetierdeBaseField.select(arg1);
        return new HomePage(browser);

    }
    
    public HomePage SetTelephone(String arg1) throws GeneralLeanFtException {
    	EditField TelephoneField =  browser.describe(EditField.class,  Telephone);
    	TelephoneField.highlight();
    	TelephoneField.setValue(arg1);
    	TelephoneField.click();
    	KeyEvent_method();
        return new HomePage(browser);

    } 
    
    public HomePage SelectStatutJuridique(String arg1) throws GeneralLeanFtException {
    	ListBox StatutJuridiqueField =  browser.describe(ListBox.class, StatutJuridique);
    	StatutJuridiqueField.highlight();
    	StatutJuridiqueField.select(arg1);
        return new HomePage(browser);

    }
    
    public HomePage SetDescriptionArtisan(String arg1) throws GeneralLeanFtException {
    	EditField DescriptionArtisanField =  browser.describe(EditField.class,  DescriptionArtisan);
    	DescriptionArtisanField.highlight();
    	DescriptionArtisanField.setValue(arg1);
        return new HomePage(browser);

    } 
    
    
    public LoginPage clickValiderBtn() throws GeneralLeanFtException, ReportException {
  	  Button Valider = browser.describe(Button.class, button_Valider);
  	  if(Valider.exists()) {
  		 System.out.println("L'objet bouton 'Valider' existe"); 
  		 Reporter.reportEvent("LoginPage", "L'objet bouton 'Valider' existe" , Status.Passed); 
  		Valider.click();
  		 
  	  }
  	  else {
  		 System.out.println("L'objet bouton 'Valider' n'existe pas");  
  		 Reporter.reportEvent("LoginPage", "L'objet bouton 'Valider' n'existe pas" , Status.Failed);
  	  }
        
        return new LoginPage(browser);
  }
    
    
    public Boolean ArtisanIsAdded() throws GeneralLeanFtException {  
    	WebElement artisan_is_Added_Msg = browser.describe(WebElement.class,  artisan_is_Added);
    	
        if (artisan_is_Added_Msg.exists(5)) return true;
        else return false;
    }
    
    
}
