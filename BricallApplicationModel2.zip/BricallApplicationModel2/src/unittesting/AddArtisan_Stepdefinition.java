package unittesting;
import org.junit.Assert;

import com.hp.lft.report.ReportException;
import com.hp.lft.report.Reporter;
import com.hp.lft.report.Status;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.Browser;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddArtisan_Stepdefinition {

    Browser browser;
    LoginPage page=new LoginPage(browser);
    HomePage homepage=new HomePage(browser);
    

    @Given("^i am on the page home of adminstrator$")
    public void i_am_on_the_page_home_of_adminstrator() throws Exception {
    	homepage.attachBrowser();
        Boolean is_login_value = homepage.isLoggedIn();

        if(is_login_value == true) {
        	Reporter.reportEvent("home page", "La page home de l'administrateur est affich�e", Status.Passed);
        }
        else
        {
        	Reporter.reportEvent("home page", "La page home de l'administrateur n'est pas affich�e", Status.Failed);
        }
        
    }

    @When("^i click on 'Add Artisan' button$")
    public void i_click_on_Add_Artisan_button() throws GeneralLeanFtException {
        homepage.clickAjouterArtisanbtn();
        
    }

    @When("^i set Nom as \"([^\"]*)\"$")
    public void i_set_Nom_as(String arg1) throws GeneralLeanFtException {
        homepage.setNom(arg1);

    }

    @When("^i set Prenom as \"([^\"]*)\"$")
    public void i_set_Prenom_as(String arg1) throws GeneralLeanFtException {
        
    	homepage.setPrenom(arg1);
    }

    @When("^i set Date de naissance as \"([^\"]*)\"$")
    public void i_set_Date_de_naissance(String arg1) throws GeneralLeanFtException {
    	homepage.setDateNaissance(arg1);
        
    }

    @When("^i set Annees d'experience as \"([^\"]*)\"$")
    public void i_set_Annees_d_experience_as(String arg1) throws GeneralLeanFtException {
    	homepage.SetAnneesExperience(arg1);
        
    }
    
    @When("^i select Ville as \"([^\"]*)\"$")
    public void i_select_Ville_as(String arg1) throws GeneralLeanFtException {
    	homepage.SelectVille(arg1);
        
    }

    @When("^i select Quartier as \"([^\"]*)\"$")
    public void i_select_Quartier_as(String arg1) throws GeneralLeanFtException {
    	homepage.SelectQuartier(arg1);
        
    }

    @When("^i select Quartiers secondaires as \"([^\"]*)\"$")
    public void i_select_Quartiers_secondaires_as(String arg1) throws GeneralLeanFtException {
    	homepage.SelectQuartiersSecondaires(arg1);
        
    }

    @When("^i select Metier de base as \"([^\"]*)\"$")
    public void i_select_Metier_de_base_as(String arg1) throws Throwable {
    	homepage.SelectMetierdeBase(arg1);

    }

    @When("^i set Telephone as \"([^\"]*)\"$")
    public void i_set_Telephone_as(String arg1) throws Throwable {
    	homepage.SetTelephone(arg1);

    }

    @When("^i select Statut juridique as \"([^\"]*)\"$")
    public void i_select_Statut_juridique_as(String arg1) throws GeneralLeanFtException {
    	homepage.SelectStatutJuridique(arg1);
        
    }

    @When("^i set Description sur l'artisan as \"([^\"]*)\"$")
    public void i_set_Description_sur_l_artisan_as(String arg1) throws GeneralLeanFtException {
    	homepage.SetDescriptionArtisan(arg1);
        
    }

    @When("^I select a profile picture$")
    public void i_select_a_profile_picture() throws GeneralLeanFtException {
        
        
    }

    @When("^I select one or more pictures in the job list$")
    public void i_select_one_or_more_pictures_in_the_job_list() throws GeneralLeanFtException {
        
        
    }

    @When("^I click on Valider button$")
    public void i_click_on_Valider_button() throws GeneralLeanFtException, ReportException {
    	homepage.clickValiderBtn();
        
    }

    @Then("^the Artisan is added successfully$")
    public void the_Artisan_is_added_successfully() throws GeneralLeanFtException {
        Boolean is_login_value = homepage.ArtisanIsAdded();
        Assert.assertEquals(true,is_login_value);
        
    }
	
}
